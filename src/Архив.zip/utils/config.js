export const apiSettings = {
    baseURL: 'http://130.61.153.224'
}